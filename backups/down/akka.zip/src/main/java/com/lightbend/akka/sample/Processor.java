package com.lightbend.akka.sample;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class Processor {

    public static void main(String[] args) {
        List<String> list = getList();

        long t1 = System.currentTimeMillis();
        List<String> list2 = new ArrayList<>();
        for (String s : list) {
            list2.add(doSlow(s));
        }
        long t2 = System.currentTimeMillis();
        System.out.println("Foreach iterator: " + (t2 - t1) + "ms");

        long t3 = System.currentTimeMillis();
        list2 = list.stream().map(Processor::doSlow).collect(Collectors.toList());
        long t4 = System.currentTimeMillis();
        System.out.println("Stream: " + (t4 - t3) + "ms");

        t3 = System.currentTimeMillis();
        list2 = list.parallelStream().map(Processor::doSlow).collect(Collectors.toList());
        t4 = System.currentTimeMillis();
        System.out.println("Parallel Stream: " + (t4 - t3) + "ms");

        t3 = System.currentTimeMillis();
        List<CompletableFuture<String>> futures = list.stream()
                .map(s -> CompletableFuture.supplyAsync(() -> doSlow(s))).collect(Collectors.toList());
        list2 = futures.stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList());
        t4 = System.currentTimeMillis();
        System.out.println("Completable future: " + (t4 - t3) + "ms");

        t3 = System.currentTimeMillis();
        ExecutorService executor = Executors.newFixedThreadPool(Math.min(list.size(), 10));
        List<CompletableFuture<String>> futures2 = list.stream()
                .map(s -> CompletableFuture.supplyAsync(() -> doSlow(s), executor)).collect(Collectors.toList());
        list2 = futures2.stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList());
        t4 = System.currentTimeMillis();
        executor.shutdown();
        System.out.println("Completable future with executor: " + (t4 - t3) + "ms");

        System.out.println("List2: " + list2.size());
    }

    private static List<String> getList() {
        return "QWERTY"//UIOPASDFGHJKLÇZXCVBNM"
                .chars()
                .mapToObj(c -> "" + c)
                .collect(Collectors.toList());
    }

    private static String doSlow(String c) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return c + " ";
    }
}
